<?php
namespace Mailgun\Messages\Exceptions;

class TooManyParameters extends \Exception{}

?>