<?php
namespace Mailgun\Connection\Exceptions;

class GenericHTTPError extends \Exception{}

?>